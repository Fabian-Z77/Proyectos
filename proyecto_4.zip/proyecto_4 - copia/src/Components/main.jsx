import React,{useState,useRef,useEffect} from "react";
import "./assets/css/style.css";
import logoEmpresa from "../img/logoEmpresa.jpg";
import { Muestra } from "./solicitudes";
import { Semilla } from "./semillas";
import { Mostrar_solicitudes } from "./mostrar_solicitudes";






export function Main(){

    const [todos,setTodos] = useState([

    ]);
    const [semillas, setSemilla] = useState([]);

// le da invisibilidad a las alertas puestas
    const invisibilidad = {
        display: 'none',   
    };   

    const nuevorun = useRef();
    const nuevonombre = useRef();
    const nuevogiro=useRef();
    
    const nuevorunR=useRef();
    const nuevonombreR=useRef();
    const nuevafechaentrega=useRef();
    const nuevacantidad=useRef();
    const nuevotipo=useRef();
    const nuevoprecioventa=useRef();
    const nuevafoto = useRef();



    useEffect (() =>{
        const importDataSemilla = async() =>{
            try{
                    const resultado1 = await fetch("http://localhost/solicitudes/semilla.php");
                    const datosSemilla = await resultado1.json();
                    console.log(datosSemilla);
                    setSemilla(datosSemilla);
                }catch(error){
                    console.log("El error producido es: "+ error);
                }
        }
            importDataSemilla();
        },[])





// funciones de las alertas
    function aparecer_alerta_vacio(){
        const div = document.getElementById("alertavacio");
        div.style.display = "block";
    }
    function desaparecer_alerta_vacio(){
        const div = document.getElementById("alertavacio");
        div.style.display = "none";
    }

    function aparecer_alerta_enviado(){
        const div = document.getElementById("alertaenviado");
        div.style.display = "block";
    }
    function desaparecer_alerta_enviado(){
        const div = document.getElementById("alertaenviado");
        div.style.display = "none";
    }

    function aparecer_alerta_eliminado(){
        const div = document.getElementById("alertaeliminado");
        div.style.display = "block";
    }
    function desaparecer_alerta_eliminado(){
        const div = document.getElementById("alertaeliminado");
        div.style.display = "none";
    }   

    
    function agregar_solicitud(){
        const newrun = nuevorun.current.value;
        const newnombre = nuevonombre.current.value;
        const newgiro = nuevogiro.current.value;
        
        const newrunR = nuevorunR.current.value;
        const newnombreR = nuevonombreR.current.value;
        const newfechaentrega=nuevafechaentrega.current.value;
        const newcantidad=nuevacantidad.current.value;
        const newtipo=nuevotipo.current.value;
        const newprecioventa=nuevoprecioventa.current.value;
        const newfoto=nuevafoto.current.value;

        const run_vacio = newrun.trim()
        const nombre_vacio = newnombre.trim()
        const giro_vacio = newgiro.trim()

        const runR_vacio = newrunR.trim()
        const nombreR_vacio = newnombreR.trim()

        const fechaentrega_vacio = newfechaentrega.trim()
        const cantidad_vacio = newcantidad.trim()
        const tipo_vacio = newtipo.trim()
        const precio_venta_vacio = newprecioventa.trim()
        const foto_vacio = newfoto.trim()




        if(tipo_vacio===""|| run_vacio === "" || nombre_vacio === "" || giro_vacio==="" || runR_vacio==="" || nombreR_vacio===""  || fechaentrega_vacio==="" || cantidad_vacio==="" 
        || precio_venta_vacio==="" || foto_vacio===""){
            aparecer_alerta_vacio()
            setTimeout(function(){
                desaparecer_alerta_vacio()

            },3500);     

            return;
        }

        aparecer_alerta_enviado()

        setTimeout(function(){
            desaparecer_alerta_enviado()    
        },1500);
        
        
        if (newrun == null) return;
        
        setTodos((prevTask) => {
            const newTask = {
                run:newrun,
                nombre:newnombre,
                giro:newgiro,
                runR:newrunR,
                nombreR:newnombreR,
                fechaentrega:newfechaentrega,
                cantidad:newcantidad,
                tipo:newtipo,
                precioventa:newprecioventa,
                foto:newfoto
            }
            return [...prevTask,newTask]
        });

        nuevorun.current.value = null;
        nuevonombre.current.value = null;
        nuevogiro.current.value = null;
        nuevorunR.current.value = null;
        nuevonombreR.current.value = null;
        nuevafechaentrega.current.value = null;
        nuevacantidad.current.value = null;
        nuevotipo.current.value = null;
        nuevoprecioventa.current.value = null;
        nuevafoto.current.value = null;
    }

    const eliminar_solicitud = (run) => {

        const nueva_lista = todos.filter((todo) => todo.run !== run);
        setTodos(nueva_lista);

        aparecer_alerta_eliminado()
        setTimeout(function(){
            desaparecer_alerta_eliminado()

        },3500); 
    }







    return <>


    <div className="container color-blanco">
        <div className="row">
            <div className="col col-6 borde">

            <div className="alert alert-danger" style={invisibilidad} role="alert" id="alertavacio">
                Algunos campos estan vacios...
            </div>

            <div className="alert alert-success" style={invisibilidad} role="alert" id="alertaenviado">
                Solicitud enviada
            </div>


                
                {/* Empresa input */}
                <h2 className="d-flex justify-content-center mb-4">Empresa</h2>
                <div className="d-flex justify-content-center h-25">
                    <img src={logoEmpresa} alt="" className="img-fluid img-thumbnail"/>
                </div>
                
                <div className="input-group mb-3 mt-5">
                    <span className="input-group-text" id="inputGroup-sizing-default">Run</span>
                    <input type="text" ref={nuevorun} id="run" className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
                </div>

                <div className="input-group mb-3 mt-5">
                    <span className="input-group-text" id="inputGroup-sizing-default">Nombre</span>
                    <input type="text" ref={nuevonombre} className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
                </div>

                <div className="input-group mb-3 mt-5">
                    <span className="input-group-text" id="inputGroup-sizing-default">Giro</span>
                    <input type="text" ref = {nuevogiro} className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
                </div>

                <div className="input-group mb-3 mt-5">
                    <span className="input-group-text" id="inputGroup-sizing-default">Foto URL</span>
                    <input type="text" ref = {nuevafoto} className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
                </div>

                {/* Representante input */}

                <h2 className="mt-5 d-flex justify-content-center">Representante</h2>
                                
                <div className="input-group mb-3 mt-5">
                    <span className="input-group-text" id="inputGroup-sizing-default">Run</span>
                    <input type="text" ref={nuevorunR} className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
                </div>
                                
                <div className="input-group mb-3 mt-5">
                    <span className="input-group-text" id="inputGroup-sizing-default">Nombre completo</span>
                    <input type="text" ref= {nuevonombreR} className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
                </div>

                {/* Solicitud input */}

                <h2 className="mt-5 d-flex justify-content-center">Solicitud</h2>


            
                <div className="input-group mb-3 mt-5">
                    <span className="input-group-text" id="inputGroup-sizing-default">Fecha Entrega</span>
                    <input type="text" ref={nuevafechaentrega} className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
                </div>
                                                
                <div className="input-group mb-3 mt-5">
                    <span className="input-group-text" id="inputGroup-sizing-default">Cantidad</span>
                    <input type="text" ref = {nuevacantidad} className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
                </div>
                                                
                <select className="form-select mt-5" ref={nuevotipo} id="floatingSelect" aria-label="Floating label select example">
                        <option selected>Seleccione una opcion</option>

                        {semillas.map((semilla)=>(
                            <Semilla semilla={semilla} key={semilla.ID_SEMILLA}/>
                        ))}
                </select>
                                                
                <div className="input-group mb-3 mt-5">
                    <span className="input-group-text" id="inputGroup-sizing-default">Precio de venta</span>
                    <input type="text" ref={nuevoprecioventa} className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
                </div>

                <div className="d-flex justify-content-end">
                    <button onClick={agregar_solicitud} className="btn btn-success mt-4 me-4">Enviar Solicitud</button>
                </div>
                                                
            </div>




            {/* CARD */}
            
            <div className="col col-6 borde">
            <h1 className="bg-success text-white rounder text-center mt-1"> Solicitudes </h1>
            <div className="alert alert-success"  style={invisibilidad} role="alert" id="alertaeliminado">
                Solicitud Eliminada...
            </div>
                {todos.map((todo) => (
                    <Muestra todo={todo} eliminar={eliminar_solicitud}/>
                ))}

                <Mostrar_solicitudes/>

                
                
            </div>
        </div>
    </div>
    
    </>
}