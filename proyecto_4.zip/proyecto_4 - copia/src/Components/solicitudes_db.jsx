import React from "react";

export function Solicitud({solicitud,eliminar}){
    const {COD_SOLICITUD,RUT_REPRESENTANTE,FECHA_SOLICITUD,FECHA_ENTREGA,CANTIDAD_ALMACIGOS,TIPO_ALMACIGO,PRECIO_DE_VENTA,ESTADO,FOTO_EMPRESA,NOMBRE_EMPRESA,GIRO,RUN_REPRESENTANTE} = solicitud;
    const probar = () =>{
        eliminar(COD_SOLICITUD);
    }
    return(
        <>
        <div className="card" >
            <div className="mx-2 mb-4">
                <a href="#" className="btn btn-danger w-10 me-3 mt-3" onClick={probar}>Eliminar</a>
            </div>
            <img className="card-img-top img-thumbnail" src={FOTO_EMPRESA} alt="foto de la empresa" />
            <div className="card-body">
                <h5 className=" card-title">N°solicitud: {COD_SOLICITUD}</h5>
                <h5 className=" card-title text-success">Nombre Empresa: {NOMBRE_EMPRESA}</h5>
                <h5 className=" card-title text-success">Rut Empresa: {RUT_REPRESENTANTE}</h5>
                <p className="card-text text-info ">Run Representante: {RUN_REPRESENTANTE}</p>
                <p className="card-text text-info">Giro Empresa: {GIRO}</p>
                <p className="card-text text-info">Tipo almacigo: {TIPO_ALMACIGO}</p>
                <p className="card-text text-info">precio de venta unitaria: ${PRECIO_DE_VENTA}</p>
                <p className="card-text text-info">Fecha de la solicitud :{FECHA_SOLICITUD}</p>
                <p className="card-text text-info">fecha de entrega: {FECHA_ENTREGA}</p>
                <p className="card-text text-info">cantidad a entregar: {CANTIDAD_ALMACIGOS}</p>
                <p className="card-text text-info">estado del pedido: {ESTADO}</p>
            </div>
        </div>
        </>
    );
}