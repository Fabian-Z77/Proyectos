import React from "react"
import logo from "../img/logo.jpg";

export function Nav(){
return <>
<nav className="navbar navbar-expand-lg bg-success" data-bs-theme="dark">
    <div class="container-fluid">
        <a className="navbar-brand" href="#">
            <img src={logo} alt="Logo" width="50" class="d-inline-block align-text-top imagen logo "/>
            All Mas
        </a>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse " id="navbarSupportedContent">
        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
            <a className="nav-link active " aria-current="page" href="./index.html">Inicio</a>
            </li>
            <li className="nav-item">
            <a className="nav-link" href="#">Productos</a>
            </li>
            <li className="nav-item">
            <a className="nav-link" href="#">Servicios</a>
            </li>
            <li className="nav-item dropdown">
            <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Usuario
            </a>
            <ul className="dropdown-menu bg-success ">
                <li><a class="dropdown-item text-white" href="#a">Perfil</a></li>
                <li><hr class="dropdown-divider"/></li>
                <li><a class="dropdown-item text-white" href="./loginCliente.html">Cambiar usuario</a></li>
                <li><hr class="dropdown-divider"/></li>
                <li><a class="dropdown-item text-white" href="./index.html">Cerrar sesion</a></li>
            </ul>
            </li>
        </ul>
        </div>
        <div className="container-fluid">
        <button onclick="cambiarTema()" class="btn rounded-fill"><svg id="dl-icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-moon-fill" viewBox="0 0 16 16">
            <path id="dll-icon" d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z"/>
        </svg></button>
        </div>
    </div>
</nav>
</>



}