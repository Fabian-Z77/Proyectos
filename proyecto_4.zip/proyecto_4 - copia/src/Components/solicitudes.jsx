import React from "react";

export function Muestra({todo,eliminar}){

    const {run,nombre,giro,runR,nombreR,fechaentrega,cantidad,tipo,precioventa,foto} = todo;
    const fecha_actual = new Date();
    const fecha_actual_string = fecha_actual.toDateString();
    const estado = "En proceso";

    const probar = () =>{
        eliminar(run);

    }
    return(
        <>
        <div className="card" >
            <div className="mx-2 mb-4">
                <a href="#" className="btn btn-danger w-10 me-3 mt-3" onClick={probar}>Eliminar</a>
            </div>
            <img className="card-img-top img-thumbnail" src={foto} alt="foto de la empresa" />
            <div className="card-body">
                <h5 className=" card-title">N°solicitud: </h5>
                <h5 className=" card-title text-success">Nombre Empresa: {nombre}</h5>
                <h5 className=" card-title text-success">Rut Empresa: {run}</h5>
                <p className="card-text text-info ">Run Representante: {runR}</p>
                <p className="card-text text-info ">Nombre Representabte: {nombreR}</p>
                <p className="card-text text-info">Giro Empresa: {giro}</p>
                <p className="card-text text-info">Tipo almacigo: {tipo}</p>
                <p className="card-text text-info">precio de venta unitaria: ${precioventa}</p>
                <p className="card-text text-info">Fecha de la solicitud :{fecha_actual_string}</p>
                <p className="card-text text-info">fecha de entrega: {fechaentrega}</p>
                <p className="card-text text-info">cantidad a entregar: {cantidad}</p>
                <p className="card-text text-info">estado del pedido: {estado}</p>
            </div>
        </div>
        </>
    );
}