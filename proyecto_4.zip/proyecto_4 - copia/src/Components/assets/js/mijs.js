const temaOscuro = () => {
    document.querySelector("body").setAttribute("data-bs-theme","dark");    
    document.querySelector("#dl-icon").setAttribute("class","bi bi-sun-fill");
    document.querySelector("#dll-icon").setAttribute("d","M8 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z");
    document.querySelector("#ok1").setAttribute("class","circulo color-Negro");
    document.querySelector("#ok2").setAttribute("class","circulo color-Negro");
    document.querySelector("#ok3").setAttribute("class","circulo color-Negro");
    document.querySelector("#ok4").setAttribute("class","circulo color-Negro");
}
const temaClaro = () => {
    document.querySelector("body").setAttribute("data-bs-theme","ligth");    
    document.querySelector("#dl-icon").setAttribute("class","bi bi-moon-fill");
    document.querySelector("#dll-icon").setAttribute("d","M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z");
    document.querySelector("#ok1").setAttribute("class","circulo color-blanco");
    document.querySelector("#ok2").setAttribute("class","circulo color-blanco");
    document.querySelector("#ok3").setAttribute("class","circulo color-blanco");
    document.querySelector("#ok4").setAttribute("class","circulo color-blanco");
}

const cambiarTema = () =>{
    document.querySelector("body").getAttribute("data-bs-theme") ==="ligth"?
    temaOscuro() : temaClaro();
}
//Mensaje eliminar cuenta
const alertPlaceholder1 = document.getElementById('liveAlertEliminarCuenta')
const appendAlert1 = (message, type) => {
  const wrapper = document.createElement('div')
  wrapper.innerHTML = [
    `<div class="alert alert-${type} alert-dismissible" role="alert">`,
    `   <div>${message}</div>`,
    '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
    '</div>'
  ].join('')

  alertPlaceholder1.append(wrapper)
}

const alertTrigger1 = document.getElementById('liveAlertEliminarClienteBtn')
if (alertTrigger1) {
  alertTrigger1.addEventListener('click', () => {
    appendAlert1('Se a eliminado el usuario de manera exitosa', 'success')
  })
}
//Mensaje Bloquear cliente
const alertPlaceholder3 = document.getElementById('liveAlertBloquearclie')
const appendAlert3 = (message, type) => {
  const wrapper = document.createElement('div')
  wrapper.innerHTML = [
    `<div class="alert alert-${type} alert-dismissible" role="alert">`,
    `   <div>${message}</div>`,
    '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
    '</div>'
  ].join('')

  alertPlaceholder3.append(wrapper)
}

const alertTrigger3 = document.getElementById('liveAlertBloquearClieBtn')
if (alertTrigger3) {
  alertTrigger3.addEventListener('click', () => {
    appendAlert3('Se a Bloqueado al usuario exitosa', 'success')
  })
}
//Mensaje Bloquear matenedor
const alertPlaceholder2 = document.getElementById('liveAlertBloquearMante')
const appendAlert2 = (message, type) => {
  const wrapper = document.createElement('div')
  wrapper.innerHTML = [
    `<div class="alert alert-${type} alert-dismissible" role="alert">`,
    `   <div>${message}</div>`,
    '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
    '</div>'
  ].join('')

  alertPlaceholder2.append(wrapper)
}

const alertTrigger2 = document.getElementById('liveAlertBloquearManteClieBtn')
if (alertTrigger2) {
  alertTrigger2.addEventListener('click', () => {
    appendAlert2('Se a Bloqueado al mantenedor de usuario exitosa', 'success')
  })
}

//Validar crear usuario
function crudCrearUsuario() {
  var nombre = document.getElementById("nombreUsuario");
  console.log("Datos ingresados:")
  //Validar nombre
  if (nombre.value.trim() == ""){
    console.log("Error en nombre");
    alert("La casilla de nombre esta vacia");
    var ok1 = document.getElementById("ok1");
    ok1.classList.remove("color-blanco");
    ok1.classList.remove("color-Negro");
    ok1.classList.remove("color-verde");
    ok1.classList.add("color-rojo");
  }else{
    var ok1 = document.getElementById("ok1");
    ok1.classList.remove("color-blanco");
    ok1.classList.remove("color-rojo");
    ok1.classList.remove("color-Negro");
    ok1.classList.add("color-verde");
    console.log("  Nombre :"+nombre.value);
  }

  var contraseña=document.getElementById("contraseña");
  //Validar contraseña
  if(contraseña.value.trim() ==""){
    console.log("Error en contraseña");
    alert("La clave esta vacia");
    var ok3 = document.getElementById("ok3");
    ok3.classList.remove("color-blanco");
    ok3.classList.remove("color-Negro");
    ok3.classList.remove("color-verde");
    ok3.classList.add("color-rojo");
  }else if(contraseña.value.trim().length < 6){
    alert("su clave debe tener al menos 6 digitos");
    var ok3 = document.getElementById("ok3");
    ok3.classList.remove("color-blanco");
    ok3.classList.remove("color-Negro");
    ok3.classList.remove("color-verde");
    ok3.classList.add("color-rojo");
  }else{
    var ok3 = document.getElementById("ok3");
    ok3.classList.remove("color-blanco");
    ok3.classList.remove("color-rojo");
    ok3.classList.remove("color-Negro");
    ok3.classList.add("color-verde");
    console.log("  Contraseña :"+ contraseña.value);
  }
  //Validar email
  var email =document.getElementById("emailUsuario");
  while(true){
    if (email.value.trim() == ""){
      console.log("Error en email");
      alert("La casilla de email esta vacia");
      var ok2 = document.getElementById("ok2");
      ok2.classList.remove("color-blanco");
      ok2.classList.remove("color-Negro");
      ok2.classList.remove("color-verde");
      ok2.classList.add("color-rojo");
      break
    }else{
      var ok2 = document.getElementById("ok2");
      ok2.classList.remove("color-blanco");
      ok2.classList.remove("color-rojo");
      ok2.classList.remove("color-Negro");
      ok2.classList.add("color-verde");
      console.log("  Email:"+email.value);
      break
    }
  }
  //Validar confirmar contraseña
  var confirContraseña = document.getElementById("confirContraseña");
  while(true){
    if(confirContraseña.value == contraseña.value && confirContraseña.value.trim() != "" ){
      var ok4 = document.getElementById("ok4");
      ok4.classList.remove("color-blanco");
      ok4.classList.remove("color-rojo");
      ok4.classList.remove("color-Negro");
      ok4.classList.add("color-verde");
      // Mensaje Crear usuario
      const alertPlaceholder4 = document.getElementById('liveAlertCrearUsuario')
      const appendAlert4 = (message, type) => {
        const wrapper = document.createElement('div')
        wrapper.innerHTML = [
          `<div class="alert alert-${type} alert-dismissible" role="alert">`,
          `   <div>${message}</div>`,
          '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
          '</div>'
        ].join('')
        alertPlaceholder4.append(wrapper)
      }
      const alertTrigger4 = document.getElementById('liveAlertCrearUsuarioBtn')
      if (alertTrigger4) {
        alertTrigger4.addEventListener('click', () => {
          appendAlert4('Se a Creado un usuario exitosa', 'success')
        })
      }
      console.log(confirContraseña.value)
      break;
    }else if (confirContraseña.value.trim() == ""){
      console.log("Error en Confirmar Contraseña");
      alert("La casilla de confirmar Contraseña no puede estar vacia");
      var ok4 = document.getElementById("ok4");
      ok4.classList.remove("color-blanco");
      ok4.classList.remove("color-Negro");
      ok4.classList.remove("color-verde");
      ok4.classList.add("color-rojo");
      break; 
    }else if(confirContraseña.value != contraseña.value){
      console.log("Error en Confirmar Contraseña");
      alert("No coincide con la contraseña puesta");
      var ok4 = document.getElementById("ok4");
      ok4.classList.remove("color-blanco");
      ok4.classList.remove("color-Negro");
      ok4.classList.remove("color-verde");
      ok4.classList.add("color-rojo");
      break;
    }
  }
  return true;
}
