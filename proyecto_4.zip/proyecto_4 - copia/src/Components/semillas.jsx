import React from "react";

export function Semilla({semilla}){
    const {ID_SEMILLA,NOMBRE_SEMILLA,PRECIO_SEMILLA} = semilla;
    return(
        <>
            <option value={ID_SEMILLA}>{NOMBRE_SEMILLA} ${PRECIO_SEMILLA}</option>
        </>
    )
}