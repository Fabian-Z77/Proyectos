import React,{useState,useEffect} from "react";
import {Solicitud} from "./solicitudes_db";
import { Semilla } from "./semillas";



export function Mostrar_solicitudes(){
    const [solicitudes, setSolicitud] = useState([]);
    
    const [semillas, setSemilla] = useState([]);

// le da invisibilidad a la alerta puesta
    const invisibilidad = {
        display: 'none',   
    };

    // funciones de la alerta
    function aparecer_alerta_eliminado(){
        const div = document.getElementById("alertaeliminado");
        div.style.display = "block";
    }
    function desaparecer_alerta_eliminado(){
        const div = document.getElementById("alertaeliminado");
        div.style.display = "none";
    } 


    const eliminar_solicitud = (run) => {

        const nueva_lista = solicitudes.filter((todo) => todo.COD_SOLICITUD !== run);
    
        setSolicitud(nueva_lista);

        aparecer_alerta_eliminado()
        setTimeout(function(){
            desaparecer_alerta_eliminado()

        },1500); 
    }

    useEffect (() =>{
        const ImportDatasolicitud = async() =>{
            try{
                const resultado = await fetch("http://localhost/solicitudes/solicitud.php");
                const datosSolicitud = await resultado.json();
                console.log(datosSolicitud);
                setSolicitud(datosSolicitud);
            }catch(error){
                console.log("El error producido es: "+ error);
            }
        }
        
        ImportDatasolicitud();
    },[])
    
    useEffect (() =>{
        const importDataSemilla = async() =>{
            try{
                    const resultado1 = await fetch("http://localhost/solicitudes/semilla.php");
                    const datosSemilla = await resultado1.json();
                    console.log(datosSemilla);
                    setSemilla(datosSemilla);
                }catch(error){
                    console.log("El error producido es: "+ error);
                }
        }
            importDataSemilla();
        },[])

    return(
        <>
            <div className="container">
                <div className="row">
                    
                    {solicitudes.map((solicitud) =>(
                        <div className=" col-1 col-sm-6 mb-3 mb-sm-0 ">
                            <div className="alert alert-success"  style={invisibilidad} role="alert" id="alertaeliminado">
                                Solicitud Eliminada...
                            </div>
                            <Solicitud solicitud={solicitud} key={solicitud.COD_SOLICITUD} eliminar={eliminar_solicitud}/>
                        </div>
                    ))}
                    
                </div>
            </div>
        </>
    )
}