import React from "react";
import {Nav} from "./Components/nav";
import {Main} from "./Components/main";
export function App(){
    return <>
    <Nav/>
    <Main/>
    
    
    </>
}